package project5.mediaDatabase.view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import project5.mediaDatabase.MediaDatabase;
import project5.mediaDatabase.model.Movie;
import project5.mediaDatabase.model.Series;

/**
*
* Project 5
* CS 2334, Section 010
* 5/5/16
* <P>
* Series Controller Class
* </P>
* @version 1.0
* 
* 
* 
*/


public class SeriesController {
    @FXML
    private TableView<Series> SeriesTable;
    @FXML
    private TableColumn<Series, String> seriesTitle;
    @FXML
    private TableColumn<Series, String> seriesReleaseYr;

    @FXML
    private Label seriesName;
    @FXML
    private Label releaseYear;
    @FXML
    private Label suspended;
    
    
    @FXML
    private Button showEpisodes;

    // Reference to the main application.
    private MediaDatabase mediaDB;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public SeriesController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the Series table with the two columns.
        seriesTitle.setCellValueFactory(new PropertyValueFactory<Series, String>("seriesTitle"));
        seriesReleaseYr.setCellValueFactory(new PropertyValueFactory<Series, String>("releaseYr"));
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mdB) {
        this.mediaDB = mdB;

        // Add observable list data to the table
        //seriesTable.setItems(mediaDB.getPersonData());
    }
}