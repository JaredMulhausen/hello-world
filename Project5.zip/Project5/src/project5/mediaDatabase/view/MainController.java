package project5.mediaDatabase.view;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import project5.mediaDatabase.MediaDatabase;

/**
*
* Project 5
* CS 2334, Section 010
* 5/5/16
* <P>
* Main Controller class
* </P>
* @version 1.0
*
*
*/

public class MainController {
    @FXML
    private Button mediaMakers;
    @FXML
    private Button media;
    @FXML
    private Button episode;
    @FXML
    private Button series;
    @FXML
    private Button movie;
    @FXML
    private Button director;
    @FXML
    private Button producer;
    @FXML
    private Button actor;
    

    // Reference to the main application.
    private MediaDatabase database;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public MainController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        //intentionally blank
    }
    
    @FXML
    public void showSeries() {
    	MediaDatabase show = new MediaDatabase();
    	show.showSeries();
    }
    @FXML
    public void showMovie() {
    	MediaDatabase show = new MediaDatabase();
    	show.showMovie();
    }
    @FXML
    public void showEpisode() {
    	MediaDatabase show = new MediaDatabase();
    	show.showEpisode();
    }
    @FXML
    public void showMedia() {
    	MediaDatabase show = new MediaDatabase();
    	show.showMedia();
    }
    @FXML
    public void showActor() {
    	MediaDatabase show = new MediaDatabase();
    	show.showActor();
    }
    @FXML
    public void showDirector() {
    	MediaDatabase show = new MediaDatabase();
    	show.showDirector();
    }
    @FXML
    public void showProducer() {
    	MediaDatabase show = new MediaDatabase();
    	show.showProducer();
    }
    @FXML
    public void showMediaMaker() {
    	MediaDatabase show = new MediaDatabase();
    	show.showMediaMaker();
    }
    
    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mainApp) {
        this.database = mainApp;
        
    }
}
