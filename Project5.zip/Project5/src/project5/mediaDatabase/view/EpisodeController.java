package project5.mediaDatabase.view;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import project5.mediaDatabase.MediaDatabase;
import project5.mediaDatabase.model.Series;

/**
*
* Project 5
* CS 2334, Section 010
* 5/5/16
* <P>
* Episode Controller Class
* </P>
* @version 1.0
*
* 
*/



public class EpisodeController {
    @FXML
    private TableView<Series> EpisodeTable;
    @FXML
    private TableColumn<Series, String> episodeTitle;
    @FXML
    private TableColumn<Series, String> episodeReleaseYr;

    @FXML
    private Label episodeName;
    @FXML
    private Label releaseYear;
    @FXML
    private Label seasonNumber;
    @FXML
    private Label episodeNumber;
    

    // Reference to the main application.
    private MediaDatabase mediaDB;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public EpisodeController() {
    	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the Series table with the two columns.
        //firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        //lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mdB) {
        this.mediaDB = mdB;

        // Add observable list data to the table
        //seriesTable.setItems(mediaDB.getPersonData());
    }
}