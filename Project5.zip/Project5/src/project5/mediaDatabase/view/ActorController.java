package project5.mediaDatabase.view;

import java.io.IOException;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import project5.mediaDatabase.MediaDatabase;
import project5.mediaDatabase.model.*;

public class ActorController {
    @FXML
    private TableView<Actor> personTable;
    @FXML
    private TableColumn<Actor, String> firstNameColumn;
    @FXML
    private TableColumn<Actor, String> lastNameColumn;
    
    @FXML
    private Label firstName;
    @FXML
    private Label lastName;
    @FXML
    private Button showMedia;

    // Reference to the main application.
    private MediaDatabase database;
    
    private ArrayList<Actor> directorList;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     * 
     */
    public ActorController()  {
    	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the person table with the two columns.("actorLastName")
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<Actor, String>("actorFirstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<Actor, String>("actorLastName"));
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mdb) {
        this.database = mdb;

         //Add observable list data to the table
         personTable.setItems(database.getActorData());
    }
}