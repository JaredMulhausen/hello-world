package project5.mediaDatabase.view;
import java.io.IOException;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import project5.mediaDatabase.MediaDatabase;
import project5.mediaDatabase.model.Movie;
import project5.mediaDatabase.model.Parse;


/**
*
* Project 5
* CS 2334, Section 010
* 5/5/16
* <P>
* Movie Controller class 
* </P>
* @version 1.0
*
*/
public class MovieController {
    @FXML
    private TableView<Movie> movieTable;
    @FXML
    private TableColumn<Movie, String> movieTitle;
    @FXML
    private TableColumn<Movie, String> movieReleaseYr;

    @FXML
    private Label movieName;
    @FXML
    private Label releaseYear;
    @FXML
    private Label releaseType;
    
    
    //@FXML
   // private Button showEpisodes;

    // Reference to the main application.
    private MediaDatabase mediaDB;
    private ArrayList<Movie> movie;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     * @throws IOException 
     * @throws ClassNotFoundException 
     */
    public MovieController() throws ClassNotFoundException, IOException {
    	//Parse parse = new Parse();
    	//movie = new ArrayList<Movie>(parse.readMovies("StarTrekMovies.txt"));
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the Series table with the two columns.
        movieTitle.setCellValueFactory(new PropertyValueFactory<Movie, String>("movieTitle"));
        movieReleaseYr.setCellValueFactory(new PropertyValueFactory<Movie, String>("releaseYear"));
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mdB) {
        this.mediaDB = mdB;

        // Add observable list data to the table
        //seriesTable.setItems(mediaDB.getPersonData());
    }
}