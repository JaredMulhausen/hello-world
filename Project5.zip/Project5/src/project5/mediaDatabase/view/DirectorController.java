package project5.mediaDatabase.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javafx.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import project5.mediaDatabase.MediaDatabase;
import project5.mediaDatabase.model.Actor;
import project5.mediaDatabase.model.Director;
import project5.mediaDatabase.model.Media;
import project5.mediaDatabase.model.Parse;


public class DirectorController {
    @FXML
    private TableView<Director> personTable;
    @FXML
    private TableColumn<Director, String> firstNameColumn;
    @FXML
    private TableColumn<Director, String> lastNameColumn;
    
    @FXML
    private Label firstName;
    @FXML
    private Label lastName;
    @FXML
    private Button showMedia;
    
    
    private ArrayList<Director> directorList;

    // Reference to the main application.
    private MediaDatabase database;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public DirectorController() throws IOException {
    	
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        //Initialize the person table with the two columns.
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<Director, String>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<Director, String>("lastName"));
    }

    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mdb) {
        this.database = mdb;

        //Add observable list data to the table
     //  personTable.setItems(database.getDirectorData());
    }
}