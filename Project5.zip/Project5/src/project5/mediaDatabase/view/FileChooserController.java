package project5.mediaDatabase.view;

import java.io.File;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Window;
import project5.mediaDatabase.MediaDatabase;

public class FileChooserController {
	
    @FXML
    private Button series;
    @FXML
    private Button movie;
    @FXML
    private Button director;
    @FXML
    private Button producer;
    @FXML
    private Button actor;
    
    

    // Reference to the main application.
    private MediaDatabase database;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public FileChooserController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        //intentionally blank
    }
    
    @FXML
    public void openSeries() {
    	 FileChooser fileChooser = new FileChooser();
    	 fileChooser.setTitle("Open Series File");
    	 fileChooser.getExtensionFilters().addAll(
    	         new ExtensionFilter("Text Files", "*.txt"),
    	         new ExtensionFilter("All Files", "*.*"));
    	 File selectedFile = fileChooser.showOpenDialog(database.getPrimaryStage());
    	 //if (selectedFile != null) {
    	    
    	 //}
    	
    }
    @FXML
    public void openMovie() {
   	 FileChooser fileChooser = new FileChooser();
   	 fileChooser.setTitle("Open Movie File");
   	 fileChooser.getExtensionFilters().addAll(
   	         new ExtensionFilter("Text Files", "*.txt"),
   	         new ExtensionFilter("All Files", "*.*"));
   	 File selectedFile = fileChooser.showOpenDialog(database.getPrimaryStage());

    }
    
    @FXML
    public void openActor() {
   	 FileChooser fileChooser = new FileChooser();
   	 fileChooser.setTitle("Open Director File");
   	 fileChooser.getExtensionFilters().addAll(
   	         new ExtensionFilter("Text Files", "*.txt"),
   	         new ExtensionFilter("All Files", "*.*"));
   	 File selectedFile = fileChooser.showOpenDialog(database.getPrimaryStage());
    }
    @FXML
    public void openDirector() {
   	 FileChooser fileChooser = new FileChooser();
   	 fileChooser.setTitle("Open Director File");
   	 fileChooser.getExtensionFilters().addAll(
   	         new ExtensionFilter("Text Files", "*.txt"),
   	         new ExtensionFilter("All Files", "*.*"));
   	 File selectedFile = fileChooser.showOpenDialog(database.getPrimaryStage());
    }
   
    @FXML
    public void openProducer() {
   	 FileChooser fileChooser = new FileChooser();
   	 fileChooser.setTitle("Open Producer File");
   	 fileChooser.getExtensionFilters().addAll(
   	         new ExtensionFilter("Text Files", "*.txt"),
   	         new ExtensionFilter("All Files", "*.*"));
   	 File selectedFile = fileChooser.showOpenDialog(database.getPrimaryStage());

    }

    
    /**
     * Is called by the main application to give a reference back to itself.
     * 
     * @param mainApp
     */
    public void setMainApp(MediaDatabase mainApp) {
        this.database = mainApp;
        
    }
}
