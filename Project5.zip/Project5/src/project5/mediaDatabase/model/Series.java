package project5.mediaDatabase.model;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 * Project #4
 * CS 2334, Section 010
 * March 7, 2016
 * <P>
 * The series class has the constructors. contains compareTo method for series' titles.
 * </P>
 * @version 1.0
 */

public class Series {
	
	private final StringProperty seriesTitle;
	private final StringProperty seriesYr;
	private StringProperty suspended; 
	
	private ArrayList<Episode> episodeList = new ArrayList<Episode>();
	
	/**
	 *Default Constructor
	 */
	public Series()
	{
		this(null, null);
	}
	/**
	 * Series Constructuor
	 * 
	 * @param seriesTitle
	 * @param seriesYr
	 */
	public Series(String seriesTitle, String seriesYr) {
		this.seriesTitle = new SimpleStringProperty(seriesTitle);
		this.seriesYr = new SimpleStringProperty(seriesYr);
	}
	
	/**
	 * Series Constructor
	 * 
	 * @param seriesTitle
	 * @param seriesYr
	 * @param suspended
	 */
	public Series(String seriesTitle, String seriesYr, String suspended)
	{
		this.seriesTitle = new SimpleStringProperty(seriesTitle);
		this.seriesYr = new SimpleStringProperty(seriesYr);
		this.suspended = new SimpleStringProperty(suspended);
	}
	
	
	/**
	 * This method returns the series title.
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>POST - Gets the series title of the series.
	 */
	public String getSeriesTitle(){
		return this.seriesTitle.get();
	}
	/**Gets the year
	 * 
	 * @return seriesYr
	 */
	public String getReleaseYr() {
		return this.seriesYr.get();
	}
	/**
	 * Gets suspended info
	 * 
	 * @return String
	 */
	public String getSuspended() {
		return this.suspended.get();
	}
	/**Sets the series Title
	 * @return void
	 */
	public void setSeriesTitle(String a) {
		this.seriesTitle.set(a);
	}
	/**
	 * Sets the release Year
	 * @param a
	 */
	public void setReleaseYr(String a) {
		this.seriesYr.set(a);
	}
	/**
	 * Sets suspension
	 * @param a
	 */
	public void setSuspended(String a) {
		this.suspended.set(a);
	}
	/**
	 * Adds an episode
	 * @param a
	 */
	public void addEpisode(Episode e) {
		episodeList.add(e);
	}
	/**
	 * Gets the Arraylist
	 * @param a
	 */
	public ArrayList<Episode> getEpisodeList() {
		return this.episodeList;
	}


}
