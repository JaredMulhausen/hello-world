package project5.mediaDatabase.model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The EpisodeTV class extends the Media class and is an abstract data type that
 * contains data related to episodes of a TV Series. Objects of this class type
 * DO contain episode and season information.
 * 
 */
public class Episode {
	private final StringProperty episodeTitle;// episode title goes here
	private final StringProperty releaseYear;
	private StringProperty seasonNumber;
	private StringProperty episodeNumber;

	/**
	 * Constructor for Episode class.
	 * 
	 * @param episodeTitle
	 *            Title of the episode.
	 * @param episodeReleaseYear

	 */
	public Episode(String episodeTitle, String releaseYear) {
		this.episodeTitle = new SimpleStringProperty(episodeTitle);
		this.releaseYear = new SimpleStringProperty(releaseYear);
	}
	
	public Episode(String episodeTitle, String releaseYear, String seasonNum, String episodeNum) {
		this.episodeTitle = new SimpleStringProperty(episodeTitle);
		this.releaseYear = new SimpleStringProperty(releaseYear);
		this.seasonNumber = new SimpleStringProperty(seasonNum);
		this.episodeNumber = new SimpleStringProperty(episodeNum);
	}

	/**
	 * Sets title of Episode
	 * @return episodeTitle
	 */
	public void setTitle(String a) {
		this.episodeTitle.set(a);
	}
	
	/**
	 * Sets Release Year
	 */
	public void setReleaseYear(String a) {
		this.releaseYear.set(a);
	}

	/**
	 * Sets the season number
	 * @param a
	 */
	public void setSeasonNumber(String a) {
		this.seasonNumber.set(a);
	}
	
	/**
	 * Sets the episode number
	 * @param a
	 */
	public void setEpisodeNumber(String a) {
		this.episodeNumber.set(a);
	}
	
	
	/**
	 * Gets the episode title
	 * @return episodeTitle
	 */
	public String getEpisodeTitle() {
		return this.episodeTitle.get();
	}
	/**
	 * Gets the seasonNumber
	 * @return seasonNumber
	 */
	public String getSeasonNumber() {
		return this.seasonNumber.get();
	}

	/**
	 * Gets the Episode Number
	 * @return episodeNumber
	 */
	public String getEpisodeNumber() {
		return this.episodeNumber.get();
	}

	/**
	 * This abstract method that returns a String indicating that the object is
	 * a EpisodeTV object. The method will be used in mediaDB to determine
	 * whether to return the object after a search.
	 */

}
