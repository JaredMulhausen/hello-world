package project5.mediaDatabase.model;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 * Project #4
 * CS 2334, Section 010
 * March 7, 2016
 * <P>
 * This class contains all data for Producer
 * </P>
 * @author Jared_Mulhausen
 * @version 1.0
 */
public class Producer {

	private static final long serialVersionUID = 1L;
	private final StringProperty firstName;
	private final StringProperty lastName;
	
	private ArrayList<String> roleList = new ArrayList<String>();
	private ArrayList<Producer> ProducerList = new ArrayList<Producer>();
	private ArrayList<Movie> movieList= new ArrayList<Movie>();
	private ArrayList<Series> seriesList = new ArrayList<Series>();
	
	
	/**
	 * Default Constructor
	 * 
	 */
	
	public Producer() {
		this(null, null);
	}
	/**
	 * Constructor for Producer object
	 * @param firstName
	 * @param lastName
	 * @param role
	 */
	public Producer(String firstName, String lastName)
	{
		this.firstName = new SimpleStringProperty(firstName);
		this.lastName = new SimpleStringProperty(lastName);
	}
	/**
	 * constructor for Producer Object
	 * 
	 * 
	 * @param Producer a
	 */
	public Producer(Producer a) {
		this.firstName = new SimpleStringProperty(a.getFirstName());
		this.lastName = new SimpleStringProperty(a.getLastName());
		this.roleList = a.getRoleList();
		this.movieList = a.getMovieList();
		this.seriesList = a.getSeriesList();
	}
	/**
	 * This method returns Producer's first name
	 * @return String firstName
	 */
	
	
	public StringProperty placeFirstName() {
		return this.firstName;
	}
	
	/**
	 * This method returns Producer's last name
	 * @return String lastName
	 */
	
	public StringProperty placeLastName() {
		return this.lastName;
	}
	
	/**Get the First Name!
	 * 
	 * @return String
	 */
	
	public String getFirstName()
	{
		return this.firstName.get();
	}
	
	public void setFirstName(String name) {
		this.firstName.set(name);
	}
	
	public void setLastName(String name) {
		this.lastName.set(name);;
	}
	
	/**
	 * This method returns Producer's last name
	 * @return String lastName
	 */
	public String getLastName()
	{
		return this.lastName.get();
	}
	
	/**
	 * This method returns Producer's role
	 * @return String role
	 */
	
	public void addMovie(Movie a) {
		this.movieList.add(a);
	}
	
	public void addSeries(Series a) {
		this.seriesList.add(a);
	}
	
	public void addRole(String role) {
		this.roleList.add(role);
	}
	
	public ArrayList<Movie> getMovieList() {
		return this.movieList;
	}
	
	public ArrayList<Series> getSeriesList() {
		return this.seriesList;
	}
	
	public ArrayList<String> getRoleList() {
		return this.roleList;
	}
	
	public void addProducer(Producer a) {
		this.ProducerList.add(a);
	}
	
}
