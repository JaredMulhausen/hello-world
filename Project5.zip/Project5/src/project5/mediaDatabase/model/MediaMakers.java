package project5.mediaDatabase.model;

import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class MediaMakers {
	
	private final StringProperty firstName;
	private final StringProperty lastName;
	
	private ArrayList<String> roleList;
	//private ArrayList<MediaMakers> mediaMakersList = new ArrayList<M>();
	private ArrayList<Movie> movieList;
	private ArrayList<Series> seriesList;
	
	public MediaMakers(Actor a) {
		
		this.firstName = new SimpleStringProperty(a.getFirstName());
		this.lastName = new SimpleStringProperty(a.getLastName());
		this.roleList = new ArrayList<String>(a.getRoleList());
		this.movieList = new ArrayList<Movie>(a.getMovieList());
		this.seriesList = new ArrayList<Series>(a.getSeriesList());
		
	}
	
	public MediaMakers(Producer a) {
		
		this.firstName = new SimpleStringProperty(a.getFirstName());
		this.lastName = new SimpleStringProperty(a.getLastName());
		this.roleList = new ArrayList<String>(a.getRoleList());
		this.movieList = new ArrayList<Movie>(a.getMovieList());
		this.seriesList = new ArrayList<Series>(a.getSeriesList());
		
	}
	
	public MediaMakers(Director a) {
		
		this.firstName = new SimpleStringProperty(a.getFirstName());
		this.lastName = new SimpleStringProperty(a.getLastName());
		this.roleList = new ArrayList<String>(a.getRoleList());
		this.movieList = new ArrayList<Movie>(a.getMovieList());
		this.seriesList = new ArrayList<Series>(a.getSeriesList());
		
	}
	
	public MediaMakers(String firstName, String lastName) {
		this.firstName = new SimpleStringProperty(firstName);
		this.lastName = new SimpleStringProperty(lastName);
		
	}
	
	public String getFirstName() {
		return this.firstName.get();
	}
	
	public String getLastName() {
		return this.lastName.get();
	}
	
	public ArrayList<String> getRoleList() {
		return this.roleList;
	}
	
	public ArrayList<Movie> getMovieList() {
		return this.movieList;
	}
	
	public ArrayList<Series> getSeriesList() {
		return this.seriesList;
	}

}