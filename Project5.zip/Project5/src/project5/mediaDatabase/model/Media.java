package project5.mediaDatabase.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Media implements Comparable {
	/**
	 * Variable to store all objects of Media type.
	 */
	private static List<Media> mediaList = new ArrayList<Media>();
	/**
	 * Variable to store the title of a Media object
	 */
	private String title;
	/**
	 * A Variable to store the release year of a Media object.
	 */
	private Integer releaseYear;

	
	/**
	 * A constructor that only satisfies the 'title' variable. Used if only the
	 * title of a Media object is known.
	 * 
	 * @param title
	 *            The title of the Media object that is to be created.
	 */
	public Media(String title) {
		this.title = title;
		this.releaseYear = null;
	}

	/**
	 * 
	 * @param title
	 *            The title of the Media object that is to be created.
	 * @param year
	 *            The release year of the Media Object that is to be created.
	 */
	public Media(String title, Integer year) {
		this.title = title;
		this.releaseYear = year;
	}

	/**
	 * A mutator method that changes the title of a particular Media Object.
	 * 
	 * @param title
	 *            The title that is to be given to a Media object.
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * A mutator method that changes the release year of a Media Object.
	 * 
	 * @param year
	 *            The release year that the Media Object is given,
	 */
	public void setReleaseYear(Integer year) {
		this.releaseYear = year;
	}

	/**
	 * An accessor method that returns the title of a Media object.
	 * 
	 * @return A String containing the Media objects title.
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * An accessor method that returns the release year of a Media object.
	 * 
	 * @return An Integer containing the Media objects release year.
	 */
	public Integer getReleaseYear() {
		return this.releaseYear;
	}

	/**
	 * An abstract method that returns a specific Media object in String form.
	 */
	public String toString() {
		return this.getTitle() + this.getReleaseYear();

	}

	/**
	 * Overrides the default compareTo method of the Comparable interface. This
	 * Method will arrange Media objects by title.
	 */
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return this.getTitle().compareTo(((Media) o).getTitle());
	}

}


/**
 * This class overrides the 'compare' method of the Comparator interface and
 * sorts Media objects by year.
 *
 */

final class YearComparator implements Comparator<Media> {

	@Override
	public int compare(Media o1, Media o2) {
		// TODO Auto-generated method stub
		return o1.getReleaseYear().compareTo(o2.getReleaseYear());
	}

	
}
