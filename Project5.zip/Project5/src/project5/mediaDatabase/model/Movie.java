package project5.mediaDatabase.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * The MovieTV class extends the Media class and is an abstract data type that
 * contains data related to Movies of a TV Series. Objects of this class type
 * DO contain Movie and season information.
 * 
 */
public class Movie {
	private final StringProperty MovieTitle;// Movie title goes here
	private final StringProperty releaseYear;
	private StringProperty releaseType;

	/**
	 * Constructor for Movie class.
	 * 
	 * @param MovieTitle
	 *            Title of the Movie.
	 * @param MovieReleaseYear
	 * 

	 */
	
	public Movie() {
		// TODO Auto-generated constructor stub
		this(null, null);
	}
	
	public Movie(String MovieTitle, String releaseYear) {
		this.MovieTitle = new SimpleStringProperty(MovieTitle);
		this.releaseYear = new SimpleStringProperty(releaseYear);
	}
	
	public Movie(String MovieTitle, String releaseYear, String releaseType) {
		this.MovieTitle = new SimpleStringProperty(MovieTitle);
		this.releaseYear = new SimpleStringProperty(releaseYear);
		this.releaseType = new SimpleStringProperty(releaseType);
	}

	/**
	 * Sets title of Movie
	 * @return MovieTitle
	 */
	public void setTitle(String a) {
		this.MovieTitle.set(a);
	}
	
	public StringProperty placeMovieTitle() {
		return MovieTitle;
	}
	
	public StringProperty placeReleaseYear() {
		return releaseYear;
	}
	
	/**
	 * Sets Release Year
	 */
	public void setReleaseYear(String a) {
		this.releaseYear.set(a);
	}

	/**
	 * Gets the Movie title
	 * @return MovieTitle
	 */
	public String getMovieTitle() {
		return this.MovieTitle.get();
	}
	/**
	 * Gets the seasonNumber
	 * @return seasonNumber
	 */
	public String getReleaseYear() {
		return this.releaseYear.get();
	}

}
