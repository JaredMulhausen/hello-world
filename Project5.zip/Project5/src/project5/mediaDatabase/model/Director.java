package project5.mediaDatabase.model;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 * Project #4
 * CS 2334, Section 010
 * March 7, 2016
 * <P>
 * This class contains all data for Director
 * </P>
 * @author Jared_Mulhausen
 * @version 1.0
 */
public class Director {

	private static final long serialVersionUID = 1L;
	private final StringProperty firstName;
	private final StringProperty lastName;
	
	private ArrayList<String> roleList = new ArrayList<String>();
	private ArrayList<Director> DirectorList = new ArrayList<Director>();
	private ArrayList<Movie> movieList= new ArrayList<Movie>();
	private ArrayList<Series> seriesList = new ArrayList<Series>();
	
	
	
	
	public Director() {
		this(null, null);
	}
	/**
	 * Constructor for Director object
	 * @param firstName
	 * @param lastName
	 * @param role
	 */
	public Director(String firstName, String lastName)
	{
		this.firstName = new SimpleStringProperty(firstName);
		this.lastName = new SimpleStringProperty(lastName);
	}
	
	public Director(Director a) {
		this.firstName = new SimpleStringProperty(a.getFirstName());
		this.lastName = new SimpleStringProperty(a.getLastName());
		this.roleList = a.getRoleList();
		this.movieList = a.getMovieList();
		this.seriesList = a.getSeriesList();
	}
	/**
	 * This method returns Director's first name
	 * @return String firstName
	 */
	public String getFirstName()
	{
		return this.firstName.get();
	}
	
	public void setFirstName(String name) {
		this.firstName.set(name);
	}
	
	public void setLastName(String name) {
		this.lastName.set(name);;
	}
	
	public StringProperty placeFirstName() {
		return this.firstName;
	}
	
	public StringProperty placeLastName() {
		return this.lastName;
	}
	
	/**
	 * This method returns Director's last name
	 * @return String lastName
	 */
	public String getLastName()
	{
		return this.lastName.get();
	}
	
	/**
	 * This method returns Director's role
	 * @return String role
	 */
	
	public void addMovie(Movie a) {
		this.movieList.add(a);
	}
	
	public void addSeries(Series a) {
		this.seriesList.add(a);
	}
	
	public void addRole(String role) {
		this.roleList.add(role);
	}
	
	public ArrayList<Movie> getMovieList() {
		return this.movieList;
	}
	
	public ArrayList<Series> getSeriesList() {
		return this.seriesList;
	}
	
	public ArrayList<String> getRoleList() {
		return this.roleList;
	}
	
	public void addDirector(Director a) {
		this.DirectorList.add(a);
	}
	
}

