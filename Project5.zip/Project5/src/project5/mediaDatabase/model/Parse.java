package project5.mediaDatabase.model;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NavigableSet;

import org.apache.commons.lang3.StringUtils;




public class Parse {
	
	
	public ArrayList<Actor> readActorFile(String fileName) throws IOException{
		BufferedReader r = new BufferedReader(new FileReader(fileName));
		ArrayList<Actor> actorList = new ArrayList<Actor>();
		String line;
		while((line = r.readLine()) != null)
		{ 
		    if (!line.equals("")) // don't write out blank lines
		    {
		        actorList.add(parseActor(line,actorList));
		    }
		} 
		r.close();
		return actorList;
	} 
	
	
	public ArrayList<Director> readDirectorFile(String fileName) throws IOException{
		BufferedReader r = new BufferedReader(new FileReader(fileName));
		ArrayList<Director> DirectorList = new ArrayList<Director>();
		String line;
		while((line = r.readLine()) != null)
		{ 
		    if (!line.equals("")) // don't write out blank lines
		    {
		        DirectorList.add(parseDirector(line,DirectorList));
		    }
		} 
		r.close();
		return DirectorList;
	} 
	public ArrayList<Producer> readProducerFile(String fileName) throws IOException {
		BufferedReader r = new BufferedReader(new FileReader(fileName));
		ArrayList<Producer> ProducerList = new ArrayList<Producer>();
		String line;
		while((line = r.readLine()) != null)
		{ 
		    if (!line.equals("")) // don't write out blank lines
		    {
		        ProducerList.add(parseProducer(line,ProducerList));
		    }
		} 
		r.close();
		return ProducerList;
	} 
	public ArrayList<Series> readSeries(String fileName) throws IOException, ClassNotFoundException{
		BufferedReader r = new BufferedReader(new FileReader(fileName));
		ArrayList<Series> SeriesList = new ArrayList<Series>();
		String line;
		while((line = r.readLine()) != null)
		{ 
		    if (!line.equals("")) // don't write out blank lines
		    {
		        //SeriesList.add(parseSeries(line));
		    }
		} 
		r.close();
		return SeriesList;
	}
	
	/**
	 * This file reads in the file from the user for program's use.
	 * @param filename
	 * <dd> PRE - file name from the user
	 * <dd> POST - read in the file for program
	 */
	public ArrayList<Movie> readMovies(String fileName) throws IOException, ClassNotFoundException{
		BufferedReader r = new BufferedReader(new FileReader(fileName));
		ArrayList<Movie> MovieList = new ArrayList<Movie>();
		String line;
		while((line = r.readLine()) != null)
		{ 
		    if (!line.equals("")) // don't write out blank lines
		    {
		       MovieList.add(parseMovie(line));
		    }
		} 
		r.close();
		return MovieList;
	}
	
	
	/**
	 * This method takes a line one by one from the array, and parses the information
	 * to put it into the proper category where it belongs.
	 * @param seriesInfo - This an array of Strings that contains all of the information
	 * about the movies but they are not split/parsed yet
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - There must be an array of the series' information in order to parse
	 * or split the data.
	 * <dd>POST - Using the array, it will go through the lines of code individually and
	 * see that which information falls into which section.
	 */
	public Series parseSeries(String line)
	{
		
		Series a = new Series();
		int index = 0;
		int endIndex = index;
		int titleBeginning;
		int length;
		
		String movieTitle = "";
		String role = "";
		String additionalNotes= "";
		String suspended= "";
		String releaseType = "";
		String releaseYr = "";
		String billingOrder = "";
		String date = "";
		
		String episodeTitle = "";
		String seriesTitle = "";
		String seasonNumber = "";
		String episodeNumber = "";
		
		boolean helper;
		boolean parenthesesHelper = false;
		
		

		//location of a movie title beginning
		
		titleBeginning = index;
		
		
		index = line.length() - 1;
		endIndex = index;
		while (index > titleBeginning) {
			
		if (isDigit(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			date = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		if (whiteSpace(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			index = endIndex;
		}
		
		if (removeArrow(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			billingOrder = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (removeBracket(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			role = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (isParentheses(line.charAt(index))) {
			helper = parenthesesLogic(line, index);
			if (helper == true)
			{
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 3) 
				{
					releaseType = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
					additionalNotes = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}

			} else {
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 5) {
					releaseYr = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
			}

		}
		
		if (removeCurlyBrace(line.charAt(index))) {
			helper = curlyBraceLogic(line, index);
			if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					length = index - endIndex;
						if (length <= 7)
						{
						parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) 
							{
							releaseYr = StringUtils.substring(line, endIndex + 1, index);
							--endIndex;
							index = endIndex;
							}
							else {
								String temp = StringUtils.substring(line, endIndex + 1, index);
								String[] episodeInfo = StringUtils.split(temp, '.');
								episodeNumber = episodeInfo[1];
								seasonNumber = StringUtils.removeStart(episodeInfo[0], "#");
								--endIndex;
								index = endIndex;
								if(whiteSpace(line.charAt(index))) {
									--index;
									endIndex = index;
									while(!removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									episodeTitle = StringUtils.substring(line, endIndex + 1, index + 1);
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
								}
								
							}
							
						}
						else if (length > 7) {
							parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) {
									date = StringUtils.substring(line, endIndex + 1, index);
									//seperate data, future if I have time
									--endIndex;
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
							}
						}
						
				}
			else 
			{
				helper = suspendedFinder(line, index);
				if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					suspended = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
				endIndex = parseHelper(line, index);
				episodeTitle = StringUtils.substring(line, endIndex + 1, index);
				--endIndex;
				index = endIndex;
				}
			}
			
		}
		
		if (removeQuotes(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			seriesTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = endIndex;
		}
		if(letterCheck(line.charAt(index))) {
			movieTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = titleBeginning; 
		}
		
	}
		if (seriesTitle.length() > 0 && releaseYr.length() > 0) {
			a = new Series(seriesTitle, releaseYr);
			if(episodeTitle.length() > 0 && episodeNumber.length() > 0 && seasonNumber.length() > 0) {
				Episode episode = new Episode(episodeTitle, releaseYr, seasonNumber, episodeNumber);
				a.addEpisode(episode);
			}
			
		}
		
		return a;
	}

	
	/**
	 * This method from the comparable interface will compare the Movie objects'
	 * titles and see if there is a match
	 * @param series - This is the movie object that this method will use to compare
	 * @return int
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives series object to compare
	 * <dd>POST - Returns an integer number to say if the titles matched or not
	 */

	/**
	 * This method takes a line one by one from the array, and parses the information
	 * to put it into the proper category where it belongs.
	 * @param movieInfo - This an array of Strings that contains all of the information
	 * about the movies but they are not split/parsed yet
	 * @return void
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - There must be an array of the movies' information in order to parse
	 * or split the data.
	 * <dd>POST - Using the array, it will go through the lines of code individually and
	 * see that which information falls into which section.
	 */
	public Movie parseMovie (String line) 
	{
		Movie a = new Movie();
		int index = 0;
		int endIndex = index;
		int titleBeginning;
		int length;
		
		String movieTitle = "";
		String role = "";
		String additionalNotes= "";
		String suspended= "";
		String releaseType = "";
		String releaseYr = "";
		String billingOrder = "";
		String date = "";
		
		String episodeTitle;
		String seriesTitle;
		String seasonNumber;
		String episodeNumber;
		
		boolean helper;
		boolean parenthesesHelper = false;
		
		

		//location of a movie title beginning
		
		titleBeginning = index;
		
		
		index = line.length() - 1;
		endIndex = index;
		while (index > titleBeginning) {
			
		if (isDigit(line.charAt(index))) {
			endIndex = parseDate(line, index);
			date = StringUtils.substring(line, endIndex, index);
			--endIndex;
			index = endIndex;
		}
		if (whiteSpace(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			index = endIndex;
		}
		
		if (removeArrow(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			billingOrder = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (removeBracket(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			role = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (isParentheses(line.charAt(index))) {
			helper = parenthesesLogic(line, index);
			if (helper == true)
			{
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 3) 
				{
					releaseType = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
					additionalNotes = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}

			} else {
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 5) {
					releaseYr = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
			}

		}
		
		if (removeCurlyBrace(line.charAt(index))) {
			helper = curlyBraceLogic(line, index);
			if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					length = index - endIndex;
						if (length <= 7)
						{
						parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) 
							{
							releaseYr = StringUtils.substring(line, endIndex + 1, index);
							--endIndex;
							index = endIndex;
							}
							else {
								String temp = StringUtils.substring(line, endIndex + 1, index);
								String[] episodeInfo = StringUtils.split(temp, '.');
								episodeNumber = episodeInfo[1];
								seasonNumber = StringUtils.removeStart(episodeInfo[0], "#");
								--endIndex;
								index = endIndex;
								if(whiteSpace(line.charAt(index))) {
									--index;
									endIndex = index;
									while(!removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									episodeTitle = StringUtils.substring(line, endIndex + 1, index + 1);
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
								}
								
							}
							
						}
						else if (length > 7) {
							parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) {
									date = StringUtils.substring(line, endIndex + 1, index);
									//seperate data, future if I have time
									--endIndex;
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
							}
						}
						
				}
			else 
			{
				helper = suspendedFinder(line, index);
				if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					suspended = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
				endIndex = parseHelper(line, index);
				episodeTitle = StringUtils.substring(line, endIndex + 1, index);
				--endIndex;
				index = endIndex;
				}
			}
			
		}
		
		if (removeQuotes(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			seriesTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = endIndex;
		}
		if(letterCheck(line.charAt(index))) {
			movieTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = titleBeginning; 
		}
		
	}
		if (movieTitle.length() > 0 && releaseYr.length() > 0) {
			a = new Movie(movieTitle, releaseYr);
		}
		
		if (movieTitle.length() > 0 && releaseYr.length() > 0 && releaseType.length() > 0) {
			a = new Movie(movieTitle, releaseYr, releaseType);
		}
		
		return a;
	}
	
	/**
	 * This method from the comparable interface will compare the Movie objects'
	 * titles and see if there is a match
	 * @param movie - This is the movie object that this method will use to compare
	 * @return int
	 * <dt><b>Conditions:</b>
	 * <dd>PRE - Receives Movie object to compare
	 * <dd>POST - Returns an integer number to say if the titles matched or not
	 */
	
	private final static boolean removeQuotes(char c) {
		return c == '"';
	}
	
	/**
	 * This method contains the specific characters that are arrows. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	
	private final static boolean removeArrow (char c) {
		return c == '<' || c == '>';
	}
	
	private final static boolean removeComma(char c) {
		return c == ',';
	}
	
	/**
	 * This method contains the specific characters that are brackets. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean removeBracket(char c) {
		return c == '[' || c == ']';
	}
	
	/**
	 * This method contains the specific numbers that are digits. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isDigit(char c){
		return c>= '0' && c <= '9';
	}
	
	/**
	 * This method contains the specific characters that are considered spaces or tabs. 
	 * It helps the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean whiteSpace(char c) {
	 return	c == ' ' || c == '\t';
	}
	
	/**
	 * This method contains the specific characters that are parentheses. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isParentheses(char c) {
		return c == '(' || c == ')';	
	}
	
	/**
	 * This method contains the specific numbers that are digits. It helps
	 * the parser method
	 * @param         Char c    		Contains individual characters.
	 * @return        boolean			Returns true or false
	 */
	private final static boolean isReleaseType(char c) {
		return c == 'T' || c == 'V';
	}
	
	private final static boolean removeCurlyBrace(char c) {
		return c == '{' || c == '}';
	}
	
	private final static boolean removeHastag(char c) {
		return c == '#';
	}
	
	private final static boolean removeQuestionMark(char c) {
		return c == '?';
	}
	private final static boolean removeDashSlashAndPeriods(char c) {
		return c == '-' || c == '.' || c == '/';
	}
	
	private final static boolean letterCheck(char c) {
		return c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z';
	}
	
	public Actor parseActor(String line, ArrayList<Actor> actorList)
	{
		Actor a;
		int index = 0;
		int endIndex = index;
		int titleBeginning;
		int length;
		
		String firstName = "";
		String lastName = "";
		String romanNumeral = "";
		String fullName = "";
		
		String movieTitle = "";
		String role = "";
		String additionalNotes= "";
		String suspended= "";
		String releaseType = "";
		String releaseYr = "";
		String billingOrder = "";
		String date = "";
		
		String seriesTitle = "";
		String episodeTitle = "";
		String seasonNumber = "";
		String episodeNumber = "";
		String episodeReleaseYr = "";
		
		boolean helper;
		boolean parenthesesHelper = false;
		
		
		if (whiteSpace(line.charAt(index))) {
			//grab the last actor entered into the map
			Actor b = actorList.get(actorList.size() - 1);
			firstName = b.getFirstName();
			lastName = b.getLastName();
		}
		
		
		if (letterCheck(line.charAt(index))) {
			while(letterCheck(line.charAt(index))) {
				lastName = lastName + line.charAt(index);
				++index;
			}
		}
		
		if (removeComma(line.charAt(index))) {
			++index;
			if(whiteSpace(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					firstName = firstName + line.charAt(index);
					++index;
				}
			}
			
		}
		
		if (whiteSpace(line.charAt(index))) {
			++index;
			if(isParentheses(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					romanNumeral = romanNumeral + line.charAt(index);
					++index;
					if (isParentheses(line.charAt(index))) {
						++index;
					}
				}
			}
		}
		
		a = new Actor(firstName, lastName);
		//lets find where the titles begin!
		while (whiteSpace(line.charAt(index))) {
			++index;
		}
		
		//location of a movie or series title
		titleBeginning = index;
		
		
		index = line.length() - 1;
		endIndex = index;
		while (index > titleBeginning) {
			
			
		if (whiteSpace(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			index = endIndex;
		}
		
		if (removeArrow(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			billingOrder = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (removeBracket(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			role = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (isParentheses(line.charAt(index))) {
			helper = parenthesesLogic(line, index);
			if (helper == true)
			{
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 3) 
				{
					releaseType = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
					additionalNotes = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}

			} else {
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 5) {
					releaseYr = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
			}

		}
		
		if (removeCurlyBrace(line.charAt(index))) {
			helper = curlyBraceLogic(line, index);
			if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					length = index - endIndex;
						if (length <= 7)
						{
						parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) 
							{
							releaseYr = StringUtils.substring(line, endIndex + 1, index);
							--endIndex;
							index = endIndex;
							}
							else {
								String temp = StringUtils.substring(line, endIndex + 1, index);
								String[] episodeInfo = StringUtils.split(temp, '.');
								episodeNumber = episodeInfo[1];
								seasonNumber = StringUtils.removeStart(episodeInfo[0], "#");
								--endIndex;
								index = endIndex;
								if(whiteSpace(line.charAt(index))) {
									--index;
									endIndex = index;
									while(!removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									episodeTitle = StringUtils.substring(line, endIndex + 1, index + 1);
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
								}
								
							}
							
						}
						else if (length > 7) {
							parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) {
									date = StringUtils.substring(line, endIndex + 1, index);
									//seperate data, future if I have time
									--endIndex;
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
							}
						}
						
				}
			else 
			{
				helper = suspendedFinder(line, index);
				if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					suspended = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
				endIndex = parseHelper(line, index);
				episodeTitle = StringUtils.substring(line, endIndex + 1, index);
				--endIndex;
				index = endIndex;
				}
			}
			
		}
		
		if (removeQuotes(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			seriesTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = endIndex;
		}
		if(letterCheck(line.charAt(index))) {
			movieTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = titleBeginning; 
		}
		
	}
		if (movieTitle.length() > 0 && releaseYr.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr);
			a.addMovie(movie);
		}
		
		if (movieTitle.length() > 0 && releaseYr.length() > 0 && releaseType.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr, releaseType);
			a.addMovie(movie);
		}
		
		if (seriesTitle.length() > 0 && releaseYr.length() > 0) {
			Series series = new Series(seriesTitle, releaseYr);
			if(episodeTitle.length() > 0 && episodeNumber.length() > 0 && seasonNumber.length() > 0) {
				Episode episode = new Episode(episodeTitle, releaseYr, seasonNumber, episodeNumber);
				series.addEpisode(episode);
			}
			a.addSeries(series);
		}
		
		return a;
	}
	
	public Director parseDirector(String line, ArrayList<Director> directorList)
	{
		Director a;
		int index = 0;
		int endIndex = index;
		int titleBeginning;
		int length;
		
		String firstName = "";
		String lastName = "";
		String romanNumeral = "";
		String fullName = "";
		
		String movieTitle = "";
		String role = "";
		String additionalNotes= "";
		String suspended= "";
		String releaseType = "";
		String releaseYr = "";
		String billingOrder = "";
		String date = "";
		
		String seriesTitle = "";
		String episodeTitle = "";
		String seasonNumber = "";
		String episodeNumber = "";
		String episodeReleaseYr = "";
		
		boolean helper;
		boolean parenthesesHelper = false;
		
		
		if (whiteSpace(line.charAt(index))) {
			//grab the last actor entered into the map
			Director b = directorList.get(directorList.size() - 1);
			firstName = b.getFirstName();
			lastName = b.getLastName();
		}
		
		
		if (letterCheck(line.charAt(index))) {
			while(letterCheck(line.charAt(index))) {
				lastName = lastName + line.charAt(index);
				++index;
			}
		}
		
		if (removeComma(line.charAt(index))) {
			++index;
			if(whiteSpace(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					firstName = firstName + line.charAt(index);
					++index;
				}
			}
			
		}
		
		if (whiteSpace(line.charAt(index))) {
			++index;
			if(isParentheses(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					romanNumeral = romanNumeral + line.charAt(index);
					++index;
					if (isParentheses(line.charAt(index))) {
						++index;
					}
				}
			}
		}
		
		a = new Director(firstName, lastName);
		//lets find where the titles begin!
		while (whiteSpace(line.charAt(index))) {
			++index;
		}
		
		//location of a movie or series title
		titleBeginning = index;
		
		
		index = line.length() - 1;
		endIndex = index;
		while (index > titleBeginning) {
			
			
		if (whiteSpace(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			index = endIndex;
		}
		
		if (removeArrow(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			billingOrder = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (removeBracket(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			role = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (isParentheses(line.charAt(index))) {
			helper = parenthesesLogic(line, index);
			if (helper == true)
			{
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 3) 
				{
					releaseType = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
					additionalNotes = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}

			} else {
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 5) {
					releaseYr = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
			}

		}
		
		if (removeCurlyBrace(line.charAt(index))) {
			helper = curlyBraceLogic(line, index);
			if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					length = index - endIndex;
						if (length <= 7)
						{
						parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) 
							{
							releaseYr = StringUtils.substring(line, endIndex + 1, index);
							--endIndex;
							index = endIndex;
							}
							else {
								String temp = StringUtils.substring(line, endIndex + 1, index);
								String[] episodeInfo = StringUtils.split(temp, '.');
								episodeNumber = episodeInfo[1];
								seasonNumber = StringUtils.removeStart(episodeInfo[0], "#");
								--endIndex;
								index = endIndex;
								if(whiteSpace(line.charAt(index))) {
									--index;
									endIndex = index;
									while(!removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									episodeTitle = StringUtils.substring(line, endIndex + 1, index + 1);
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
								}
								
							}
							
						}
						else if (length > 7) {
							parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) {
									date = StringUtils.substring(line, endIndex + 1, index);
									//seperate data, future if I have time
									--endIndex;
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
							}
						}
						
				}
			else 
			{
				helper = suspendedFinder(line, index);
				if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					suspended = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
				endIndex = parseHelper(line, index);
				episodeTitle = StringUtils.substring(line, endIndex + 1, index);
				--endIndex;
				index = endIndex;
				}
			}
			
		}
		
		if (removeQuotes(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			seriesTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = endIndex;
		}
		if(letterCheck(line.charAt(index))) {
			movieTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = titleBeginning; 
		}
		
	}
		if (movieTitle.length() > 0 && releaseYr.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr);
			a.addMovie(movie);
		}
		
		if (movieTitle.length() > 0 && releaseYr.length() > 0 && releaseType.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr, releaseType);
			a.addMovie(movie);
		}
		
		if (seriesTitle.length() > 0 && releaseYr.length() > 0) {
			Series series = new Series(seriesTitle, releaseYr);
			if(episodeTitle.length() > 0 && episodeNumber.length() > 0 && seasonNumber.length() > 0) {
				Episode episode = new Episode(episodeTitle, releaseYr, seasonNumber, episodeNumber);
				series.addEpisode(episode);
			}
			a.addSeries(series);
		}
		
		return a;
	}
	
	public Producer parseProducer(String line, ArrayList<Producer> producerList)
	{
		Producer a;
		int index = 0;
		int endIndex = index;
		int titleBeginning;
		int length;
		
		String firstName = "";
		String lastName = "";
		String romanNumeral = "";
		String fullName = "";
		
		String movieTitle = "";
		String role = "";
		String additionalNotes= "";
		String suspended= "";
		String releaseType = "";
		String releaseYr = "";
		String billingOrder = "";
		String date = "";
		
		String seriesTitle = "";
		String episodeTitle = "";
		String seasonNumber = "";
		String episodeNumber = "";
		String episodeReleaseYr = "";
		
		boolean helper;
		boolean parenthesesHelper = false;
		
		
		if (whiteSpace(line.charAt(index))) {
			//grab the last actor entered into the map
			Producer b = producerList.get(producerList.size() - 1);
			firstName = b.getFirstName();
			lastName = b.getLastName();
		}
		
		
		if (letterCheck(line.charAt(index))) {
			while(letterCheck(line.charAt(index))) {
				lastName = lastName + line.charAt(index);
				++index;
			}
		}
		
		if (removeComma(line.charAt(index))) {
			++index;
			if(whiteSpace(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					firstName = firstName + line.charAt(index);
					++index;
				}
			}
			
		}
		
		if (whiteSpace(line.charAt(index))) {
			++index;
			if(isParentheses(line.charAt(index))) {
				++index;
				while(letterCheck(line.charAt(index))) {
					romanNumeral = romanNumeral + line.charAt(index);
					++index;
					if (isParentheses(line.charAt(index))) {
						++index;
					}
				}
			}
		}
		
		a = new Producer(firstName, lastName);
		//lets find where the titles begin!
		while (whiteSpace(line.charAt(index))) {
			++index;
		}
		
		//location of a movie or series title
		titleBeginning = index;
		
		
		index = line.length() - 1;
		endIndex = index;
		while (index > titleBeginning) {
			
			
		if (whiteSpace(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			index = endIndex;
		}
		
		if (removeArrow(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			billingOrder = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (removeBracket(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			role = StringUtils.substring(line, endIndex + 1, index);
			--endIndex;
			index = endIndex;
		}
		
		if (isParentheses(line.charAt(index))) {
			helper = parenthesesLogic(line, index);
			if (helper == true)
			{
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 3) 
				{
					releaseType = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
					additionalNotes = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}

			} else {
				endIndex = parseHelper(line, index);
				length = index - endIndex;
				if (length <= 5) {
					releaseYr = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
			}

		}
		
		if (removeCurlyBrace(line.charAt(index))) {
			helper = curlyBraceLogic(line, index);
			if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					length = index - endIndex;
						if (length <= 7)
						{
						parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) 
							{
							releaseYr = StringUtils.substring(line, endIndex + 1, index);
							--endIndex;
							index = endIndex;
							}
							else {
								String temp = StringUtils.substring(line, endIndex + 1, index);
								String[] episodeInfo = StringUtils.split(temp, '.');
								episodeNumber = episodeInfo[1];
								seasonNumber = StringUtils.removeStart(episodeInfo[0], "#");
								--endIndex;
								index = endIndex;
								if(whiteSpace(line.charAt(index))) {
									--index;
									endIndex = index;
									while(!removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									episodeTitle = StringUtils.substring(line, endIndex + 1, index + 1);
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
								}
								
							}
							
						}
						else if (length > 7) {
							parenthesesHelper = parenthesesCounter(line, endIndex + 1, index);
							if (parenthesesHelper == true) {
									date = StringUtils.substring(line, endIndex + 1, index);
									//seperate data, future if I have time
									--endIndex;
									if(removeCurlyBrace(line.charAt(endIndex))) {
										--endIndex;
									}
									index = endIndex;
							}
						}
						
				}
			else 
			{
				helper = suspendedFinder(line, index);
				if (helper == true) {
					--index;
					endIndex = parseHelper(line, index);
					suspended = StringUtils.substring(line, endIndex + 1, index);
					--endIndex;
					index = endIndex;
				}
				else {
				endIndex = parseHelper(line, index);
				episodeTitle = StringUtils.substring(line, endIndex + 1, index);
				--endIndex;
				index = endIndex;
				}
			}
			
		}
		
		if (removeQuotes(line.charAt(index))) {
			endIndex = parseHelper(line, index);
			seriesTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = endIndex;
		}
		if(letterCheck(line.charAt(index))) {
			movieTitle = StringUtils.substring(line, titleBeginning, index + 1);
			index = titleBeginning; 
		}
		
	}
		if (movieTitle.length() > 0 && releaseYr.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr);
			a.addMovie(movie);
		}
		
		if (movieTitle.length() > 0 && releaseYr.length() > 0 && releaseType.length() > 0) {
			Movie movie = new Movie(movieTitle, releaseYr, releaseType);
			a.addMovie(movie);
		}
		
		if (seriesTitle.length() > 0 && releaseYr.length() > 0) {
			Series series = new Series(seriesTitle, releaseYr);
			if(episodeTitle.length() > 0 && episodeNumber.length() > 0 && seasonNumber.length() > 0) {
				Episode episode = new Episode(episodeTitle, releaseYr, seasonNumber, episodeNumber);
				series.addEpisode(episode);
			}
			a.addSeries(series);
		}
		
		return a;
	}
	
	private int parseHelper(String line, int startIndex) {
		
		int endIndex = startIndex;
		char c = line.charAt(startIndex);
		switch(c) {
		
		case ' ':
			--startIndex;
			endIndex = startIndex;
			break;
		case ')':
			c = '(';
			endIndex = parseLoop(line, startIndex, c);
			break;	
		case '>':
			c = '<';
			endIndex = parseLoop(line,startIndex, c);
			break;	
		case '}':
			c = '{';
			if(removeCurlyBrace(line.charAt(startIndex - 1))) {
				--startIndex;
				parseHelper(line, startIndex);
			}
			else if (isParentheses(line.charAt(startIndex - 1))) {
				--startIndex;
				parseHelper(line, startIndex);
			}
			endIndex = parseLoop(line, startIndex, c);
			break;
			
		case ']':
			--startIndex;
			c = '[';
			endIndex = parseLoop(line, startIndex, c);
			break;
		case '#':
			--startIndex;
			endIndex = startIndex;
		case '"':
			--startIndex;
			endIndex = parseLoop(line, startIndex, c);
			break;
		}
		return endIndex;
	}
	
	
	private int parseLoop(String line, int startIndex, char c) {
		int endIndex = startIndex;
		while(line.charAt(startIndex) != c) {
			--startIndex;
		}
		endIndex = startIndex;
		return endIndex;
	}
	
	private int parseDate(String line, int startIndex) {
		int endIndex = startIndex;
		while (isDigit(line.charAt(startIndex))) {
			--startIndex;
		}
		endIndex = startIndex;
		return endIndex;
	}
	private boolean parenthesesLogic(String line, int startIndex) {
		char c = line.charAt(startIndex - 1);
		if (letterCheck(c)) {
			return true;
		}
		else if(isDigit(c)) {
			return false;
		}
		return false;
	}
	
	private boolean curlyBraceLogic(String line, int startIndex) {
		boolean truth;
		--startIndex;
		if (isParentheses(line.charAt(startIndex))) {
			truth = true;
		}
		else {
			truth = false;
		}
		return truth;
		
	}
	
	private boolean parenthesesCounter(String line, int startIndex, int endIndex) {
		String question;
		boolean logic;
		
		question = StringUtils.substring(line, startIndex, endIndex + 1);
		logic = StringUtils.containsNone(question, '#');
		
		return logic;
	}
	
	private boolean suspendedFinder(String line, int startIndex) {
		char c = line.charAt(startIndex - 1);
		if (removeCurlyBrace(c)) {
			return true;
		}
		return false;
	}
	
	private boolean getTitle(String line, int startIndex) {
		char c = line.charAt(startIndex - 1);
		if (letterCheck(c)) {
			return true;
		}
		return false;
	}
	
	
}