package project5.mediaDatabase;
/**
 *
 * Project 5
 * CS 2334, Section 010
 * 5/5/16
 * <P>
 * Main Application Class  
 * </P>
 * @version 1.0

 */


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import project5.mediaDatabase.model.*;
import project5.mediaDatabase.view.*;


public class MediaDatabase extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
    
    
    private ObservableList<Actor> actorList = FXCollections.observableArrayList();
    private ObservableList<Director> directorList = FXCollections.observableArrayList();
    private ObservableList<Episode> episodeList = FXCollections.observableArrayList();
    private ObservableList<Series> seriesList = FXCollections.observableArrayList();
    private ObservableList<Movie> movieList = FXCollections.observableArrayList();
    private ObservableList<Producer> producerList = FXCollections.observableArrayList();
    
    
    public MediaDatabase()  {

    }

    @Override
    public void start(Stage primaryStage) throws IOException {
    	
    	this.primaryStage = primaryStage;
        this.primaryStage.setTitle("mDB");
        initRootLayout();
        showMainMenu();
    }

    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows the mainMenu overview inside the root layout.
     */
    public void showMainMenu() {
        try {
            // Load person overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/MainView.fxml"));
            AnchorPane mainMenu = (AnchorPane) loader.load();

            // Set person overview into the center of root layout.
            rootLayout.setCenter(mainMenu);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void showSeries() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/SeriesView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("Series");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            SeriesController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void showMovie() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/MovieView.fxml"));

            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("Movie");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            MovieController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void showEpisode() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/EpisodeView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("Episodes");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            EpisodeController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void showDirector() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/DirectorView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.

            Stage newStage = new Stage();
            newStage.setTitle("Directors");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            DirectorController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void showProducer() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/ProducerView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.

            Stage newStage = new Stage();
            newStage.setTitle("Producers");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            ProducerController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void showMedia() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/MediaView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("Media");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            MediaController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void showActor() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/ActorView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("Actors");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            ActorController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    


    public void showMediaMaker() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MediaDatabase.class.getResource("view/MediaMakerView.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage newStage = new Stage();
            newStage.setTitle("MediaMakers");
            newStage.initModality(Modality.WINDOW_MODAL);
            newStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            newStage.setScene(scene);

            // Set the person into the controller.
            MediaMakersController controller = loader.getController();
            // Show the dialog and wait until the user closes it
            newStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public ObservableList<Actor> getActorData() {
       return this.actorList;
    }
    
    public ObservableList<Director> getDirectorData() {
       return this.directorList;
    }
    
    public ObservableList<Producer> getProducerData() {
        return this.producerList;
    }
    
    public ObservableList<Series> getSeriesData() {
        return this.seriesList;
    }
    
    public ObservableList<Episode> getEpisodeData() {
        return this.episodeList;
    }
    
    public ObservableList<Movie> getMovieData() {
        return this.movieList;
    }
    
    public ObservableList<Media> getMediaData() {
        return null;
    }
    
    public ObservableList<MediaMakers> getMediaMakersData() {
        return null;
    }
    
    /**
     * Returns the main stage.
     * @return
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }

}
